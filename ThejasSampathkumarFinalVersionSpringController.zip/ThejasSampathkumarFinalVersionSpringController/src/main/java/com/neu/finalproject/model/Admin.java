package com.neu.finalproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ADMIN")
public class Admin extends User {
	@Column(name = "OFFICE")
	private String office;
	@Column(name = "CURRENTY_ACTIVE")
	private String currentlyActive;
	

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public String getCurrentlyActive() {
		return currentlyActive;
	}

	public void setCurrentlyActive(String currentlyActive) {
		this.currentlyActive = currentlyActive;
	}

}
