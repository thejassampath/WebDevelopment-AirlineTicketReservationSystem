package com.neu.finalproject.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class Address {
	@Column(name="STREET")
	private String street;
	@Column(name="ADDRESS_1")
	private String address1;
	@Column(name="DOOR_NO")
	private Integer doorNo;
	@Embedded
	private ZipCode zipcode;
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public ZipCode getZipcode() {
		return zipcode;
	}
	public void setZipcode(ZipCode zipcode) {
		this.zipcode = zipcode;
	}
	public Integer getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(Integer doorNo) {
		this.doorNo = doorNo;
	}
	
	
}
