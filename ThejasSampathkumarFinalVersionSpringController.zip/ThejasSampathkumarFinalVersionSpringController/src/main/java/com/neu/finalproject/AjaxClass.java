package com.neu.finalproject;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.gson.Gson;
import com.neu.finalproject.DAO.AjaxPromptUsersDao;

@Controller
public class AjaxClass extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public AjaxClass() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("application/json");
		

		try {

			String term = request.getParameter("term");
			System.out.println(term);
			AjaxPromptUsersDao ajaxPromptUsersDao = new AjaxPromptUsersDao();
			List<String> list = ajaxPromptUsersDao.getPlace(term);

			String searchList = new Gson().toJson(list);
			response.getWriter().write(searchList);

		}

		catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}

	@RequestMapping(method = RequestMethod.POST)
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");

		try {

			String term1 = request.getParameter("term1");
			System.out.println(term1);
			System.out.println("dest is" + term1 + "inside ajax class");
			AjaxPromptUsersDao ajaxPromptUsersDao = new AjaxPromptUsersDao();
			List<String> list = ajaxPromptUsersDao.getDestinationAirport(term1);

			String searchList = new Gson().toJson(list);
			response.getWriter().write(searchList);
			System.out.println("Written to console");
		}

		catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}

}
