package com.neu.finalproject.Validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.finalproject.model.Booking;
import com.neu.finalproject.model.Transaction;

public class TransactionValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Transaction.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		Transaction transaction = (Transaction) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "cardNo",
				"validate.cardNo", "Card No Is Incorrect");

	}

}
