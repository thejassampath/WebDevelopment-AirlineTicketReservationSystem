package com.neu.finalproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;

@Entity
@Table(name = "FLIGHT_INVENTORY")
public class FlightInventory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ENTRY_ID")
	private Long entryId;

	@Column(name = "CLASS")
	private String ticketClass;

	public String getTicketClass() {
		return ticketClass;
	}

	public void setTicketClass(String ticketClass) {
		this.ticketClass = ticketClass;
	}

	@ManyToOne
	@JoinColumn(name = "SCHEDULE_ID")
	private Schedule schedule;

	@Column(name = "AVAILABLE_SEATS")
	private Integer noOfSeatsAvailable;
	@Min(value = 1)
	@Column(name = "PRICE_PER_TICKET")
	private Double pricePerTicket;

	public Long getEntryId() {
		return entryId;
	}

	public void setEntryId(Long entryId) {
		this.entryId = entryId;
	}

	public Integer getNoOfSeatsAvailable() {
		return noOfSeatsAvailable;
	}

	public void setNoOfSeatsAvailable(Integer noOfSeatsAvailable) {
		this.noOfSeatsAvailable = noOfSeatsAvailable;
	}

	public Double getPricePerTicket() {
		return pricePerTicket;
	}

	public void setPricePerTicket(Double pricePerTicket) {
		this.pricePerTicket = pricePerTicket;
	}

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

}
