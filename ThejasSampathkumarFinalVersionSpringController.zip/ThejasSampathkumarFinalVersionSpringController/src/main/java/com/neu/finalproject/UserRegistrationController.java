package com.neu.finalproject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.neu.finalproject.DAO.FlightInsertDao;
import com.neu.finalproject.DAO.UserRegistrationDao;
import com.neu.finalproject.model.Booking;
import com.neu.finalproject.model.Flight;
import com.neu.finalproject.model.User;

/**
 * Handles requests for the application home page.
 */
@Controller
public class UserRegistrationController {

	private static final Logger logger = LoggerFactory
			.getLogger(UserRegistrationController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */

	@Autowired
	@Qualifier("userRegistrationValidator")
	private Validator validator;

	@Autowired
	private UserRegistrationDao userRegDao;

	/*
	 * This is to initialize webDataBinder,set its validator as we specify.
	 */
	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}



	/*
	 * @RequestMapping(value = "/", method = RequestMethod.GET) public String
	 * home(Locale locale, Model model) { Booking book = new Booking();
	 * model.addAttribute("booking", book); return "Search"; }
	 */

/*	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView initUserLoginForm(Model model) {
		ModelAndView model1 = null;
		model1 = new ModelAndView("NewUserRegistrationForm");
		User user = new User();
		model1.addObject("user", user);

		return model1;
	}
   */
//	@RequestMapping(value = "flightsuper", method = RequestMethod.POST)
//	public String InsertFlight(@RequestParam("flightType") String flightType,
//			@RequestParam("source") String source,
//			@RequestParam("destination") String destination,
//			@RequestParam("scheduleName") String scheduleName,
//			@RequestParam("arrivalDate") String arrivalDate,
//			@RequestParam("departureDate") String departureDate,
//			@RequestParam("arrivalTime") String arrivalTime,
//			@RequestParam("departureTime") String departureTime,
//			@RequestParam("ticketClass") String ticketClass,
//			@RequestParam("noOfSeatsAvailable") Integer noOfSeatsAvailable,
//			@RequestParam("pricePerTicket") Double pricePerTicket, Model model) {
//
//		try {
//			//Flight fl = flightInsert.InsertFlight(flightType, source,
//					destination, scheduleName, arrivalDate, departureDate,
//					arrivalTime, departureTime, ticketClass,
//					noOfSeatsAvailable, pricePerTicket);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		return "home";
//	}

	@RequestMapping(value = "userRegistration", method = RequestMethod.POST)
	public ModelAndView userRegistration(Model model, @Validated User user,
			BindingResult result) {

		if (result.hasErrors()) {
			ModelAndView model1 = null;
			model1 = new ModelAndView("NewUserRegistrationForm");
			model1.addObject("user", user);
			return model1;

		} else {
			try {

				User u = userRegDao.userRegistration(user);
			} catch (Exception e) {

			}

			return new ModelAndView("AdminDashBoard");

		}

	}

	

	 
	
	
	

}
