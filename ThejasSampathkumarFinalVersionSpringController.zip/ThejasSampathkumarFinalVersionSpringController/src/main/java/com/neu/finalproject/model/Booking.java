package com.neu.finalproject.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "BOOKING")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BOOKING_ID")
	private Long bookingId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "USER_ID")
	private User user;
	
	private Date departureDate;
	
	private Date returnDate;
	private Integer noOfBags;
	private Double totalAmount;
	private Long flightOne;
	private Double pricePerTicketOne;
	private Double pricePerTicketTwo;
	private Long flightTwo;
	private String source;
	private String destination;
	private String waytravel;
	private String classpassenger;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "transaction_Id")
	private Transaction transaction;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "meal_Id")
	private Meal meal;

	@Min(value = 1)
	@Column(name = "NO_OF_PASSENGERS")
	private Integer noOfPassengers;

	@Temporal(TemporalType.DATE)
	@Column(name = "BOOKING_DATE")
	private Date bookingDate;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "booking")
	private Set<Passenger> passenger = new HashSet<Passenger>();
	
	
	public Set<Passenger> getPassenger() {
		return passenger;
	}

	public void setPassenger(Set<Passenger> passenger) {
		this.passenger = passenger;
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Integer getNoOfBags() {
		return noOfBags;
	}

	public void setNoOfBags(Integer noOfBags) {
		this.noOfBags = noOfBags;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Integer getNoOfPassengers() {
		return noOfPassengers;
	}

	public void setNoOfPassengers(Integer noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public Meal getMeal() {
		return meal;
	}

	public void setMeal(Meal meal) {
		this.meal = meal;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}



	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getWaytravel() {
		return waytravel;
	}

	public void setWaytravel(String waytravel) {
		this.waytravel = waytravel;
	}

	public String getClasspassenger() {
		return classpassenger;
	}

	public void setClasspassenger(String classpassenger) {
		this.classpassenger = classpassenger;
	}

	public Long getFlightOne() {
		return flightOne;
	}

	public void setFlightOne(Long flightOne) {
		this.flightOne = flightOne;
	}

	public Long getFlightTwo() {
		return flightTwo;
	}

	public void setFlightTwo(Long flightTwo) {
		this.flightTwo = flightTwo;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Double getPricePerTicketOne() {
		return pricePerTicketOne;
	}

	public void setPricePerTicketOne(Double pricePerTicketOne) {
		this.pricePerTicketOne = pricePerTicketOne;
	}

	public Double getPricePerTicketTwo() {
		return pricePerTicketTwo;
	}

	public void setPricePerTicketTwo(Double pricePerTicketTwo) {
		this.pricePerTicketTwo = pricePerTicketTwo;
	}

}
