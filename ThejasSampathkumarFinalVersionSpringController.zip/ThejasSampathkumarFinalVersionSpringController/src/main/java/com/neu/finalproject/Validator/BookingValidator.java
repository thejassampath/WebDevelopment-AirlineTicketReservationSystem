package com.neu.finalproject.Validator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Set;

import org.hamcrest.core.Is;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.finalproject.model.Booking;

public class BookingValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Booking.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		Booking booking = (Booking) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "source",
				"validate.source", "Source Is Incorrect");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "destination",
				"validate.destination", "Destination Is Incorrect");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "waytravel",
				"required.waytravel", "way Travel should be selected");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "departureDate",
				"validate.departureDate", "DepartureDate Is Incorrect");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "returnDate",
				"validate.returnDate", "returnDate Is Incorrect");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "noOfPassengers",
				"validate.noOfPassengers", "noOfPassengers Is Incorrect");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Classpassenger",
				"required.Classpassenger");
		if (booking.getNoOfPassengers() < 1) {
			errors.rejectValue("noOfPassengers", "validate.noOfPassengers",
					"No of passengers is incorrect");
		}
		if (booking.getDepartureDate() == null) {
			errors.rejectValue("departureDate", "validate.departureDate",
					"DepartureDate Is Incorrect");
		}
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		String reportDate = df.format(booking.getDepartureDate());

		if(booking.getDepartureDate().equals(reportDate)){
			errors.rejectValue("departureDate", "validate.departureDate",
					"DepartureDate Is Incorrect");
		}
		 
		if (booking.getDepartureDate().after(booking.getReturnDate())
				|| booking.getDepartureDate().equals(booking.getReturnDate())) {
			errors.rejectValue("departureDate", "validate.departureDate",
					"DepartureDate Is Incorrect");
			errors.rejectValue("returnDate", "validate.returnDate",
					"returnDate Is Incorrect");
		}
	}
}
