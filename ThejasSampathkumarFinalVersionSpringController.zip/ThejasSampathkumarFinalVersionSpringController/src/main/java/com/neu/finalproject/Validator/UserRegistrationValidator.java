package com.neu.finalproject.Validator;



import java.util.Set;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.finalproject.model.Address;
import com.neu.finalproject.model.Booking;
import com.neu.finalproject.model.User;
import com.neu.finalproject.model.ZipCode;

public class UserRegistrationValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		User user = (User) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName",
				"validate.userName", "Please enter valid user name");
	
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPassword",
				"validate.userPassword", "not a valid paddword");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phoneNo",
				"validate.phoneNo", "not a valid phone number");
	/*	ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName",
				"validate.firstName", "not a valid first name");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName",
				"validate.lastName", "not a valid last name"); */
		ValidationUtils
				.rejectIfEmptyOrWhitespace(errors, "age", "required.age", "not a valid age");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors,
				"passengerClassPreference",
				"validate.passengerClassPreference",
				"not a valid class preference");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,
				"preferredDestination", "validate.preferredDestination",
				"not a valid preferred destination");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address.doorNo",
				"validate.address.doorNo", "not a valid address");

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address.street",
				"validate.address.street", "not a valid street");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,
				"address.zipcode.city", "validate.address.zipcode.city",
				"not a valid city");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address.zipcode.country",
				"validate.address.zipcode.country", "not a valid country");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors,
				"address.zipcode.state", "required.address.zipcode.state","not a valid state");
		
		
		/*not a valid
		if(!user.getFirstName().isEmpty()) {
			if(!user.getFirstName().matches("[a-zA-Z]+"))
				errors.rejectValue("firstName", "user.firstName.invalid", new Object[]{user.getFirstName()}, "Only letters allowed");
		}

	/*	public class FullValidator implements Validator{
			@Override
			public boolean supports(Class<?> clazz) {
				
				return UserAccount.class.equals(clazz);
			}

			@Override
			public void validate(Object target, Errors errors) {
				// TODO Auto-generated method stub
				UserAccount userAccount = (UserAccount)target;
				Person person = userAccount.getPerson();
				Address address = person.getAddress();
				System.out.println("In full Validator");
						
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.firstName", "validate.person.firstName", "Please enter First Name");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.lastName", "validate.person.lastName", "Please enter Last Name");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.contactNumber", "validate.person.contactNumber", "Please enter Contact Number");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.dob", "validate.person.dob", "Please enter DOB");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.address.street", "validate.person.address.street", "Please enter Street");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.address.city", "validate.person.address.city", "Please enter City");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.address.state", "validate.person.address.state", "Please enter State");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.address.country", "validate.person.address.country", "Please enter Country");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "person.address.zipcode", "validate.person.address.zipcode", "Please enter Zipcode");
				
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "validate.userName", "Please enter UserName");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "validate.password", "Please enter Password");
				ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword", "validate.confirmPassword", "Please enter Confirm Password");
				ValidationUtils.rejectIfEmpty(errors, "type", "validate.type", "Please select valid account type");
				
				
				
			\\ Check personal details */
			/*	if(!person.getFirstName().isEmpty()) {
					if(!person.getFirstName().matches("[a-zA-Z]+"))
						errors.rejectValue("person.firstName", "person.firstName.invalid", new Object[]{userAccount.getPerson().getFirstName()}, "Only letters allowed");
				}
				if(!person.getLastName().isEmpty()) {
					if(!person.getLastName().matches("[a-zA-Z]+"))
						errors.rejectValue("person.lastName", "person.lastName.invalid", new Object[]{userAccount.getPerson().getLastName()}, "Only letters allowed");
				}
				if(!person.getContactNumber().isEmpty()) {
					if(!person.getContactNumber().matches("[0-9]{3}-[0-9]{3}-[0-9]{4}"))
						errors.rejectValue("person.contactNumber", "person.contactNumber.invalid", new Object[]{userAccount.getPerson().getContactNumber()}, "Format is ddd-ddd-dddd");
				}
				
				if(!address.getStreet().isEmpty()) {
					if(!address.getStreet().matches("[a-zA-Z0-9\\s]+"))
						errors.rejectValue("person.address.street", "person.address.street.invalid", new Object[]{address.getStreet()}, "Only digits and alphabets allowed");
				}
				if(!address.getZipcode().getCity().isEmpty()) {
					if(!address.getCity().matches("[a-zA-Z\\s]+"))
						errors.rejectValue("person.address.city", "person.address.city.invalid", new Object[]{address.getCity()}, "Only alphabets allowed");
				}
				if(!address.getState().isEmpty()) {
					if(!address.getState().matches("[a-zA-Z\\s]+"))
						errors.rejectValue("person.address.state", "person.address.state.invalid", new Object[]{address.getState()}, "Only alphabets allowed");
				}
				if(!address.getCountry().isEmpty()) {
					if(!address.getCountry().matches("[a-zA-Z\\s]+"))
						errors.rejectValue("person.address.country", "person.address.country.invalid", new Object[]{address.getCountry()}, "Only alphabets allowed");
				}
				if(!address.getZipcode().isEmpty()) {
					if(!address.getZipcode().matches("[0-9]{5}"))
						errors.rejectValue("person.address.zipcode", "person.address.zipcode.invalid", new Object[]{address.getZipcode()}, "Valid zipcode is 5 digits");
				}
				
				
				 	
				*/
			
			

		}

		

	}



