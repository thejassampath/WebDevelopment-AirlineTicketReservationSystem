package com.neu.finalproject.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name = "Flight")
@Table(name = "FLIGHT")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FLIGHT_ID")
	private Long flightId;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "flight")
	Set<Schedule> schedule = new HashSet<Schedule>();

	@Column(name = "FLIGHT_TYPE")
	private String flightType;

	@Column(name = "MAINTAINECE_CONDITION")
	private String maintained;

	@Column(name = "SOURCE")
	private String source;
	@Column(name = "DESTINATION")
	private String destination;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Long getFlightId() {
		return flightId;
	}

	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}

	public String getFlightType() {
		return flightType;
	}

	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	public String getMaintained() {
		return maintained;
	}

	public void setMaintained(String maintained) {
		this.maintained = maintained;
	}

	public Set<Schedule> getSchedule() {
		return schedule;
	}

	public void setSchedule(Set<Schedule> schedule) {
		this.schedule = schedule;
	}

}
