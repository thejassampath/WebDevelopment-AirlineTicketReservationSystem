package com.neu.finalproject.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "USER")
public class User extends Person {
	@Column(name = "PASSENGER_CLASS_PREF")
	private String passengerPreference;

	public String getPassengerPreference() {
		return passengerPreference;
	}

	public void setPassengerPreference(String passengerPreference) {
		this.passengerPreference = passengerPreference;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<Booking> booking = new HashSet<Booking>();

	public Set<Booking> getBooking() {
		return booking;
	}

	public void setBooking(Set<Booking> booking) {
		this.booking = booking;
	}

}
