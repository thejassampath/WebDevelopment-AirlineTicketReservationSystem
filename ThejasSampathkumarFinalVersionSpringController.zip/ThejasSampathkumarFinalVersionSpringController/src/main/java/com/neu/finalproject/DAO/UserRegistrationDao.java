package com.neu.finalproject.DAO;

import javax.management.relation.Role;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.neu.finalproject.model.Address;
import com.neu.finalproject.model.Flight;
import com.neu.finalproject.model.FlightInventory;
import com.neu.finalproject.model.Schedule;
import com.neu.finalproject.model.User;
import com.neu.finalproject.model.ZipCode;

public class UserRegistrationDao extends DAO {

	public User userRegistration(User user)  /*String userName, String userPassword,
			Long phoneNo, String firstName, String lastName, String age,
			String passengerClassPreference, String preferredDestination,

			String role, String street, Integer doorNo, String city,
			String state, String country) */ throws Exception {

		try {
			Session s = getSession();
			Transaction t = s.beginTransaction();
User u = new User();
	u.setEnabled(1);
		
			 
			
		
			s.persist(user);
			s.persist(u);
			
			t.commit();

			System.out.println("\n\n Details Added \n");
			return user;

		} catch (Exception e) {
			// rollback();
			
			System.out.println("errot" +e);
			throw new Exception("Could not insert " + user.getUserName(), e);
		} finally {

			// getSession().flush();
			getSession().close();

		}
	}
   
	

	
	}
   
	
	
	
	

