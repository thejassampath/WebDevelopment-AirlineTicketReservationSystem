package com.neu.finalproject;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;






import com.neu.finalproject.DAO.FlightInsertDao;
import com.neu.finalproject.model.Flight;
import com.neu.finalproject.model.FlightInventory;
import com.neu.finalproject.model.Person;
import com.neu.finalproject.model.Schedule;
import com.neu.finalproject.model.User;

@Controller
public class AddNewFlightAdminController {

	private static final Logger logger = LoggerFactory
			.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */


	@Autowired
	private FlightInsertDao flightInsertDao;



	@RequestMapping(value = "/adminWorks", method = RequestMethod.POST)
	public ModelAndView addFlights(Model model) {
		ModelAndView model2 = null;
		Flight flight = new Flight();
		model2 = new ModelAndView("addDetailsAboutFlightnewone");
		model2.addObject("flight",flight);
		return model2;
	}
	

	@RequestMapping(value = "flightsuper",method = RequestMethod.GET)
	public String InsertFlight(@RequestParam("flightType") String flightType,@RequestParam("source1") String source1,
			@RequestParam("destination1") String destination1,@RequestParam("maintained") String maintained,
			@RequestParam("scheduleName")
			String scheduleName,@RequestParam("arrivalDate") Date arrivalDate,
			@RequestParam("departureDate") Date departureDate,@RequestParam("arrivalTime") Date arrivalTime,
			@RequestParam("departureTime") Date departureTime,
			@RequestParam("ticketClass") String ticketClass,@RequestParam("noOfSeatsAvailable") Integer noOfSeatsAvailable,
			@RequestParam("pricePerTicket") Double pricePerTicket
			,
			Model model) {
		
		
		try {
			Flight fl = flightInsertDao.InsertFlight(flightType, source1, destination1,maintained, scheduleName, arrivalDate, departureDate, arrivalTime, departureTime, ticketClass, noOfSeatsAvailable, pricePerTicket);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "addsuccesssflight";
	}
}
