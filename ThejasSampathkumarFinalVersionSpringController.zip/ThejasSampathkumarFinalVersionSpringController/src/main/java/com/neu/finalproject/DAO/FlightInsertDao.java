package com.neu.finalproject.DAO;

import java.util.Date;

import javax.persistence.Column;
import javax.validation.constraints.Min;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.neu.finalproject.model.Flight;
import com.neu.finalproject.model.FlightInventory;
import com.neu.finalproject.model.Schedule;

public class FlightInsertDao extends DAO {

	public Flight InsertFlight(String flightType, String source1,
			String destination1,String maintained, String scheduleName, Date arrivalDate,
			Date departureDate, Date arrivalTime, Date departureTime,
			String ticketClass, Integer noOfSeatsAvailable,
			Double pricePerTicket) throws Exception {

		try {
			Session s = getSession();
			Transaction t = s.beginTransaction();

			Flight f = new Flight();

			f.setFlightType(flightType);
f.setMaintained(maintained);
			f.setSource(source1);

			f.setDestination(destination1);

			Schedule sc = new Schedule();

			sc.setScheduleName(scheduleName);
			
			sc.setArrivalDate(arrivalDate);
			sc.setArrivalTime(arrivalTime);
			sc.setDepartureDate(departureDate);
			sc.setDepartureTime(departureTime);

			sc.setFlight(f);

			FlightInventory fc = new FlightInventory();
			fc.setTicketClass(ticketClass);
			
			fc.setNoOfSeatsAvailable(noOfSeatsAvailable);
			fc.setPricePerTicket(pricePerTicket);
			
		
			fc.setSchedule(sc);

			s.persist(f);
			s.persist(fc);
			s.persist(sc);

			t.commit();

			System.out.println("\n\n Details Added \n");
			return f;

		} catch (HibernateException e) {
	
			throw new Exception("Could not insert " +flightType, e);
		} finally {

			getSession().close();

		}
	}

}
