package com.neu.finalproject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.inject.Inject;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.neu.finalproject.DAO.SearchFlightDao;
import com.neu.finalproject.Validator.PassengerValidator;
import com.neu.finalproject.model.Booking;
import com.neu.finalproject.model.Meal;
import com.neu.finalproject.model.Passenger;
import com.neu.finalproject.model.Transaction;

@Controller
public class SearchFlightByUserController {
	@Autowired
	@Qualifier("bookingValidator")
	private Validator validator;
	@Autowired
	@Qualifier("transactionValidator")
	private Validator transactionValidator;

	@Autowired
	private SearchFlightDao searchFlightDao;

	@InitBinder("booking")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	@InitBinder("transaction")
	private void initBinder1(WebDataBinder transBinder) {
		transBinder.setValidator(transactionValidator);
	}

	private Booking booking;

	@RequestMapping(value = "/searchthis")
	public String searchResult1s(Model model, @Validated Booking booking,
			BindingResult result) {
		if (result.hasErrors()) {
			model.addAttribute("booking", booking);
			return "user";
		}
		List<Object[]> result2 = searchFlightDao.getflights(booking);
		model.addAttribute("result", result2);
		model.addAttribute("booking", booking);
		this.booking = booking;
		return "displayresults";

	}

	@RequestMapping(value = "firstbooking")
	public String searchResults(Model model,
			@RequestParam Long FlightSelection1,
			@RequestParam Double priceperticket1) {
		
		
		if (booking.getWaytravel().equals("OneWay")
				|| booking.getFlightOne() == null) {booking.setTotalAmount((double) 0);

			booking.setFlightOne(FlightSelection1);
			booking.setPricePerTicketOne(priceperticket1);
			booking.setTotalAmount(booking.getTotalAmount()+(priceperticket1*booking.getNoOfPassengers()));
		}
			else {
			booking.setFlightTwo(FlightSelection1);
			booking.setPricePerTicketTwo(priceperticket1);
			booking.setTotalAmount(booking.getTotalAmount()+(priceperticket1*booking.getNoOfPassengers()));
		}
		if (booking.getWaytravel().equals("OneWay") || booking.getFlightTwo() == FlightSelection1) {
			model.addAttribute("booking", booking);
			List<Meal> meal = searchFlightDao.getMeals();
			model.addAttribute("meal", meal);
			return "bags";
		} else {
			List<Object[]> result2 = searchFlightDao.getreturnflights(booking);
			model.addAttribute("result", result2);
			model.addAttribute("booking", booking);
		}
		return "displayresults";
	}

	@RequestMapping(value = "payment")
	public String payment1(Model model, @RequestParam String mealId,
			@RequestParam Integer bag) {
		booking.setMeal(searchFlightDao.getMeal(mealId));
		booking.setNoOfBags(bag);
		if(booking.getClasspassenger().equals("Economy") && booking.getNoOfBags()>2){
			booking.setTotalAmount(booking.getTotalAmount()+(25*(booking.getNoOfBags()-2)));
		} else if(booking.getClasspassenger().equals("Business") && booking.getNoOfBags()>4){
			booking.setTotalAmount(booking.getTotalAmount()+(25*(booking.getNoOfBags()-4)));
		}else if (booking.getClasspassenger().equals("FirstClass") && booking.getNoOfBags()>3){
			booking.setTotalAmount(booking.getTotalAmount()+(25*(booking.getNoOfBags()- 3)));
		}
		Transaction transaction = new Transaction();
		model.addAttribute("transaction", transaction);
		return "payment";

	}

	@RequestMapping(value = "confirmationpage")
	public String payment(Model model, @Validated Transaction transaction,
			BindingResult result) {
		if (result.hasErrors()) {
			return "payment";
		}
		booking.setTransaction(transaction);
		model.addAttribute("booking", booking);
		// List<Passenger> passenger = new ArrayList<Passenger>();
		// model.addAttribute("passenger", passenger);
		return "confirmation";

	}

	@RequestMapping(value = "/search")
	public String home(Locale locale, Model model) {
		Booking book = new Booking();
		model.addAttribute("booking", book);
		return "Search";
	}

	@RequestMapping(value = "con")
	public String pass(Model model,
			@RequestParam(value = "passengername[]") String[] passengername,
			@RequestParam(value = "passengerage[]") Integer[] passengerage,
			@RequestParam(value = "passport[]") String[] passport) {
		Set<Passenger> passengerSet = new HashSet<Passenger>();
		for (int i = 0; i < booking.getNoOfPassengers(); i++) {
			Passenger passenger = new Passenger();
			passenger.setPassengerName(passengername[i]);
			passenger.setPassengerAge(passengerage[i]);
			passenger.setPassportNumber(passport[i]);
			passengerSet.add(passenger);
		}
		booking.setPassenger(passengerSet);
		model.addAttribute("booking", booking);
		return "finalconfirm";

	}

}
