package com.neu.finalproject.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name = "Schedule")
@Table(name = "SCHEDULE")
public class Schedule {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SCHEDULE_ID")
	private Long scheduleId;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "schedule")
	Set<FlightInventory> flightInventory = new HashSet<FlightInventory>();

	private String scheduleName;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FLIGHT_ID")
	private Flight flight;
	@Temporal(TemporalType.DATE)
	private Date arrivalDate;
	@Temporal(TemporalType.DATE)
	private Date departureDate;

	private Date arrivalTime;

	private Date departureTime;

	public Long getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}

	@Column(name = "ARRIVAL_DATE")
	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	@Column(name = "DEPARTURE_DATE")
	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	@Temporal(TemporalType.TIME)
	@Column(name = "ARRIVAL_TIME")
	public Date getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	@Column(name = "SCHEDULE_NAME")
	public String getScheduleName() {
		return scheduleName;
	}

	public void setScheduleName(String scheduleName) {
		this.scheduleName = scheduleName;
	}

	@Temporal(TemporalType.TIME)
	@Column(name = "DEPARTURE_TIME")
	public Date getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public Set<FlightInventory> getFlightInventory() {
		return flightInventory;
	}

	public void setFlightInventory(Set<FlightInventory> flightInventory) {
		this.flightInventory = flightInventory;
	}

}
