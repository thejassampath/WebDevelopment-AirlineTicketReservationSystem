package com.neu.finalproject.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Meal {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MEAL_ID")
	private Long mealId;
	@Column(name = "MEAL_TYPE")
	private String mealType;
	@Column(name = "COMMENTS")
	private String comments;

	public Long getMealId() {
		return mealId;
	}

	public void setMealId(Long mealId) {
		this.mealId = mealId;
	}

	public String getMealType() {
		return mealType;
	}

	public void setMealType(String mealType) {
		this.mealType = mealType;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
