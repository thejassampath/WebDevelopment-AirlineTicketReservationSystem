package com.neu.finalproject.Validator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import org.hamcrest.core.Is;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.finalproject.model.Booking;
import com.neu.finalproject.model.Passenger;

public class PassengerValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Passenger.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		ArrayList<Passenger> passengerList = (ArrayList<Passenger>) target;
		for (int i = 1; i <= passengerList.size(); i++) {
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, passengerList
					.get(i).getPassengerName(), "PassengerName Is Incorrect");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors,
					String.valueOf(passengerList.get(i).getPassengerAge()),
					"PassengerAge Is Incorrect");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors,
					String.valueOf(passengerList.get(i).getPassportNumber()),
					"PassportNumber Is Incorrect");
		}

	}
}
