package com.neu.finalproject.DAO;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;

import com.neu.finalproject.model.Booking;
import com.neu.finalproject.model.Flight;
import com.neu.finalproject.model.Meal;

public class SearchFlightDao extends DAO {

	public List<Object[]> getflights(Booking booking) {
		String newstartstring = new SimpleDateFormat("yyyy-MM-dd")
				.format(booking.getDepartureDate());
		Query q = getSession()
				.createQuery(
						"select f.flightId,fi.pricePerTicket,fi.noOfSeatsAvailable,s.departureDate,s.arrivalDate,s.departureTime,s.arrivalTime from Flight f inner join f.schedule s inner join s.flightInventory fi where f.source =:source and f.destination =:destination and fi.ticketClass =:ticketclass and fi.noOfSeatsAvailable >=:noofseats and s.departureDate =:date")
				.setString("source", booking.getSource())
				.setString("destination", booking.getDestination())
				.setString("ticketclass", booking.getClasspassenger())
				.setString("noofseats",
						String.valueOf(booking.getNoOfPassengers()))
				.setString("date", newstartstring);
		List<Object[]> result = q.list();
		return result;
	}
	
	public List<Object[]> getreturnflights(Booking booking) {
		String newstartstring = new SimpleDateFormat("yyyy-MM-dd")
				.format(booking.getReturnDate());
		Query q = getSession()
				.createQuery(
						"select f.flightId,fi.pricePerTicket,fi.noOfSeatsAvailable,s.departureDate,s.arrivalDate,s.departureTime,s.arrivalTime from Flight f inner join f.schedule s inner join s.flightInventory fi where f.source =:source and f.destination =:destination and fi.ticketClass =:ticketclass and fi.noOfSeatsAvailable >=:noofseats and s.departureDate =:date")
				.setString("source", booking.getDestination())
				.setString("destination", booking.getSource())
				.setString("ticketclass", booking.getClasspassenger())
				.setString("noofseats",
						String.valueOf(booking.getNoOfPassengers()))
				.setString("date", newstartstring);
		List<Object[]> result = q.list();
		return result;
	}

	public List<Meal> getMeals() {
		Query q = getSession().createQuery("from Meal");
		List<Meal> result = q.list();
		return result;
	}

	public Meal getMeal(String mealId) {
		Query q = getSession().createQuery("from Meal where meal_id=:meal")
				.setString("meal", mealId);
		Meal result = (Meal) q.uniqueResult();
		return result;
	}
}
