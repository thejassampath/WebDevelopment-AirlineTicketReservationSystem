package com.neu.finalproject.DAO;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.finalproject.model.Person;
import com.neu.finalproject.model.User;


public class PersonDetailsDao extends DAO {

	public User searchPerson(Integer userId) throws Exception {
	
		
		try {
			
			 Query q = getSession().createQuery("from User where userId = :userId");
			 
			 
	            q.setString("userId", (String.valueOf(userId)));
	            User p = (User) q.uniqueResult();
	            System.out.println(p);
		return p;
		
	
		} catch (HibernateException e) {
			System.out.println(e);
			throw new Exception("Could not get user " + userId, e);
		}
	}
}
	

