package com.neu.finalproject.DAO;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

public class AjaxPromptUsersDao extends DAO {

	public List<String> getPlace(String sourceAirport) throws Exception {

		try {
			// begin();
			Session session = getSession();
			Query q = session
					.createQuery
					("select f.source from Flight f where f.source like :sourceAirport");

			q.setString("sourceAirport", sourceAirport + "%");

			List<String> unique = q.list();

			System.out.println(unique + "is found");
			return unique;

		} catch (HibernateException e) {
			// rollback();
			throw new Exception("Could not get source Aiport " + sourceAirport
					+ e.getMessage());
		}

	}

	public List<String> getDestinationAirport(String destinationAiport)
			throws Exception {

		try {
			// begin();
			Session session = getSession();
			Query q = session
					.createQuery

					("select f.destination from Flight f where f.destination like :destinationAiport");

			q.setString("destinationAiport", destinationAiport + "%");

			List<String> unique = q.list();
			System.out.println(unique + "is found");
			return unique;

		} catch (HibernateException e) {
			// rollback();
			throw new Exception("Could not get source dest Aiport "
					+ destinationAiport + e.getMessage());
		}

	}

}
