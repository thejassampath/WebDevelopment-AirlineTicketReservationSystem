package com.neu.plane;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.neu.finalproject.DAO.HibernateUtil;

public class SearchClass {
	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction t = session.beginTransaction();
			t.commit();
			session.close();
			System.out.println("Success");
			
			
		}
}
